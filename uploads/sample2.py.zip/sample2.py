def greet(name):
    """Greets the user by name."""
    message = create_message(name)
    print(message)

def create_message(name):
    ok= greet(name)
    return f"Hello, {name}!"

def main():
    greet("Raghid")
