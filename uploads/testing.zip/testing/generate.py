import ast
import os
import sys
import inspect
from pyvis.network import Network

class FunctionVisitor(ast.NodeVisitor):
    def __init__(self, code_lines):
        self.functions = {}  # {qualified_name: {"calls": set(), "code": str}}
        self.current_function = None
        self.current_class = None
        self.code_lines = code_lines

    def visit_ClassDef(self, node):
        self.current_class = node.name
        self.generic_visit(node)
        self.current_class = None

    def visit_FunctionDef(self, node):
        name = node.name
        if self.current_class:
            qualified_name = f"{self.current_class}.{name}"
        else:
            qualified_name = name

        start_line = node.lineno - 1
        end_line = node.end_lineno if hasattr(node, 'end_lineno') else node.lineno + len(node.body)
        code = "".join(self.code_lines[start_line:end_line])

        self.functions[qualified_name] = {
            "calls": set(),
            "code": code
        }

        self.current_function = qualified_name
        self.generic_visit(node)
        self.current_function = None

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        else:
            func_name = None

        if self.current_function and func_name:
            self.functions[self.current_function]["calls"].add(func_name)

        self.generic_visit(node)

def build_graph(filepath):
    with open(filepath, "r") as f:
        code_lines = f.readlines()
        tree = ast.parse("".join(code_lines))

    visitor = FunctionVisitor(code_lines)
    visitor.visit(tree)

    net = Network(height="800px", width="100%", directed=True)
    net.barnes_hut()

    for func_name, details in visitor.functions.items():
        net.add_node(
            func_name,
            label=func_name,
            title=f"<pre>{details['code']}</pre>",
            shape="box",
            color="#AED6F1",
            value=200,  # size of the node
            font={"size": 100, "face": "arial", "align": "center"}
        )
        

    for caller, details in visitor.functions.items():
        for callee in details["calls"]:
            if callee in visitor.functions:
                net.add_edge(caller, callee)

    output_file = "function_dependency_graph.html"
    net.write_html(output_file)
    
    # Inject sidebar
    with open(output_file, "r", encoding="utf-8") as f:
        html = f.read()

    # Generate sidebar HTML
    sidebar_html = """
    <div id="sidebar" style="position: fixed; left: 0; top: 0; width: 200px; height: 100%; background: #f4f4f4; padding: 10px; overflow-y: auto; border-right: 1px solid #ccc; z-index: 9999;">
        <h3 style="margin-top: 0;">Functions</h3>
        <input type="text" id="functionSearch" placeholder="Search..." style="width: 100%; padding: 5px; margin-bottom: 10px; font-size: 14px; box-sizing: border-box;">
        <ul id="functionList" style="list-style: none; padding-left: 0; font-family: sans-serif; font-size: 14px;">
    """
    for func_name in visitor.functions:
        sidebar_html += f'<li style="margin-bottom: 8px; cursor: pointer;" onclick="selectNode(\'{func_name}\')">{func_name}</li>\n'
    sidebar_html += "</ul></div>"

    # Inject sidebar and JS
    injection = f"""
    {sidebar_html}

    <!-- Function code viewer -->
    <div id="codeBox">
        <div id="resizeHandle"></div>
        <div id="codeContent"><em>Click a function to see its code here.</em></div>
    </div>

    <style>
    #mynetwork {{
        margin-left: 200px;
    }}
    #codeBox {{
        position: fixed;
        bottom: 0;
        left: 200px;
        right: 0;
        height: 250px;
        background: #f9f9f9;
        border-top: 1px solid #ccc;
        z-index: 9999;
        box-sizing: border-box;
        min-height: 100px;
        max-height: 600px;
        display: flex;
        flex-direction: column;
        font-family: monospace;
        font-size: 13px;
        white-space: pre-wrap;
    }}

    #resizeHandle {{
        height: 8px;
        cursor: ns-resize;
        background: #ddd;
        border-top: 1px solid #ccc;
    }}

    #codeContent {{
        flex: 1;
        overflow: auto;
        padding: 10px;
    }}
    </style>

    <script>
    const codeBox = document.getElementById("codeBox");
    const resizeHandle = document.getElementById("resizeHandle");
    let isResizing = false;
    let startY = 0;
    let startHeight = 0;

    resizeHandle.addEventListener("mousedown", function (e) {{
        isResizing = true;
        startY = e.clientY;
        startHeight = codeBox.offsetHeight;
        document.body.style.cursor = 'ns-resize';
        e.preventDefault();
    }});

    document.addEventListener("mousemove", function (e) {{
        if (!isResizing) return;
        const dy = startY - e.clientY;
        let newHeight = startHeight + dy;
        newHeight = Math.max(100, Math.min(600, newHeight)); // set limits
        codeBox.style.height = newHeight + "px";
    }});

    document.addEventListener("mouseup", function () {{
        if (isResizing) {{
            isResizing = false;
            document.body.style.cursor = 'default';
        }}
    }});

    // Sidebar click
    function selectNode(name) {{
        const nodes = window.network.body.nodes;
        const node = Object.values(nodes).find(n => n.options.label === name);
        if (node) {{
            const nodeId = node.id;
            const position = network.getPositions([nodeId])[nodeId];
            network.selectNodes([node.id]);
            network.moveTo({{ position: {{ x: position.x, y: position.y }},scale: 1.5, offset: {{ x: 0, y: -190 }},animation: true }});
        }}
        // Show the code directly instead of emitting a fake click event
        const code = node.options.title.replace(/<[^>]*>?/gm, "");
        document.getElementById("codeContent").innerText = code;
    }}

    // Graph node click
    network.on("click", function (params) {{
        if (params.nodes.length > 0) {{
            const nodeId = params.nodes[0];
            const nodeData = network.body.nodes[nodeId].options;
            const code = nodeData.title.replace(/<[^>]*>?/gm, "");  // strip HTML tags
            document.getElementById("codeContent").innerText = code;
        }}
    }});

    document.getElementById("functionSearch").addEventListener("input", function () {{
        const query = this.value.toLowerCase();
        const items = document.querySelectorAll("#functionList li");
        items.forEach(function (item) {{
            if (item.textContent.toLowerCase().includes(query)) {{
                item.style.display = "";
            }}else {{
                item.style.display = "none";
            }}
        }});
    }});
    </script>
    """

    # Place sidebar before closing </body>
    html = html.replace("</body>", injection + "\n</body>")

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ Graph saved with sidebar: {output_file}")
    print(f"✅ Graph saved as {output_file}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python generate_graph.py sample2.py")
    else:
        build_graph(sys.argv[1])
