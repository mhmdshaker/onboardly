
"""Small math helpers."""
def square(x: float) -> float:
    return x * x

def mean(nums):
    return sum(nums) / len(nums) if nums else 0
